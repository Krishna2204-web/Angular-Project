﻿namespace Books
{
    public class UserLogin
    {
        public string EmailAddress { get; set; }
        public string Password { get; set; }
    }
}
